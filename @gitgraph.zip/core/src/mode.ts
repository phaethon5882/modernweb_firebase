export { Mode };

enum Mode {
  Compact = "compact",
}
