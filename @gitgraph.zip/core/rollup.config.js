export default {
  input: "lib/index.js",
  output: {
    file: "lib/bundle.umd.js",
    format: "umd",
  },
};
