export { Mode };
declare enum Mode {
    Compact = "compact"
}
