export declare enum Orientation {
    VerticalReverse = "vertical-reverse",
    Horizontal = "horizontal",
    HorizontalReverse = "horizontal-reverse"
}
