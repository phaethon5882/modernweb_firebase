import { Tag } from "@gitgraph/core";
export { createTag, PADDING_X };
declare const PADDING_X = 10;
declare function createTag(tag: Tag<SVGElement>): SVGGElement;
